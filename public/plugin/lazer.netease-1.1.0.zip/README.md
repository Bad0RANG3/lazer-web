# 网易云音乐 Lua Gateway

这是 Lazer 的跨平台 Lua Plugin 示例。将本目录打包成 ZIP 后，在客户端的「设置 → 扩展 → 插件管理」中导入。

插件只依赖宿主提供的 `host.http`、`host.crypto`、`host.storage_*` 和 JSON helpers；不调用文件系统、进程、动态库或平台 API。协议实现、登录 Cookie、搜索、歌单、歌词、音频 URL 与播放统计都在 `netease.lua` 中。

详情见客户端仓库 `docs/lua-plugins.md`。
